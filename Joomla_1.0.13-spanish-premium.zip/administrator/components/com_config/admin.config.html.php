<?php
/**
* @version $Id: admin.config.html.php 7424 2007-05-17 15:56:10Z robs $
* @package Joomla
* @subpackage Config
* @Translator: Joomla Spanish 
* @Review : shacker | 22/07/07
* @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
// no direct access
defined( '_VALID_MOS' ) or die( 'Acceso restringido' );
/**
* @package Joomla
* @subpackage Config
*/
class HTML_config {

	function showconfig( &$row, &$lists, $option) {
		global $mosConfig_absolute_path, $mosConfig_live_site, $mosConfig_session_type;
		
		$tabs = new mosTabs(0);
		?>
		<script type="text/javascript">
		<!--
		function saveFilePerms() {
			var f = document.adminForm;
			if (f.filePermsMode0.checked)
				f.config_fileperms.value = '';
			else {
				var perms = 0;
				if (f.filePermsUserRead.checked) perms += 400;
				if (f.filePermsUserWrite.checked) perms += 200;
				if (f.filePermsUserExecute.checked) perms += 100;
				if (f.filePermsGroupRead.checked) perms += 40;
				if (f.filePermsGroupWrite.checked) perms += 20;
				if (f.filePermsGroupExecute.checked) perms += 10;
				if (f.filePermsWorldRead.checked) perms += 4;
				if (f.filePermsWorldWrite.checked) perms += 2;
				if (f.filePermsWorldExecute.checked) perms += 1;
				f.config_fileperms.value = '0'+''+perms;
			}
		}
		function changeFilePermsMode(mode) {
			if(document.getElementById) {
				switch (mode) {
					case 0:
						document.getElementById('filePermsValue').style.display = 'none';
						document.getElementById('filePermsTooltip').style.display = '';
						document.getElementById('filePermsFlags').style.display = 'none';
						break;
					default:
						document.getElementById('filePermsValue').style.display = '';
						document.getElementById('filePermsTooltip').style.display = 'none';
						document.getElementById('filePermsFlags').style.display = '';
				} // switch
			} // if
			saveFilePerms();
		}
		function saveDirPerms() {
			var f = document.adminForm;
			if (f.dirPermsMode0.checked)
				f.config_dirperms.value = '';
			else {
				var perms = 0;
				if (f.dirPermsUserRead.checked) perms += 400;
				if (f.dirPermsUserWrite.checked) perms += 200;
				if (f.dirPermsUserSearch.checked) perms += 100;
				if (f.dirPermsGroupRead.checked) perms += 40;
				if (f.dirPermsGroupWrite.checked) perms += 20;
				if (f.dirPermsGroupSearch.checked) perms += 10;
				if (f.dirPermsWorldRead.checked) perms += 4;
				if (f.dirPermsWorldWrite.checked) perms += 2;
				if (f.dirPermsWorldSearch.checked) perms += 1;
				f.config_dirperms.value = '0'+''+perms;
			}
		}
		function changeDirPermsMode(mode) 	{
			if(document.getElementById) {
				switch (mode) {
					case 0:
						document.getElementById('dirPermsValue').style.display = 'none';
						document.getElementById('dirPermsTooltip').style.display = '';
						document.getElementById('dirPermsFlags').style.display = 'none';
						break;
					default:
						document.getElementById('dirPermsValue').style.display = '';
						document.getElementById('dirPermsTooltip').style.display = 'none';
						document.getElementById('dirPermsFlags').style.display = '';
				} // switch
			} // if
			saveDirPerms();
		}
		function submitbutton(pressbutton) {
			var form = document.adminForm;
			
			// do field validation
			if (form.config_session_type.value != <?php echo $row->config_session_type; ?> ){
				if ( confirm('Estas seguro de cambiar a `M�todo de autentificaci�n de sesi�n`? \n\n Esto har� que todas las sesiones existentes en el frontend o parte p�blica sean suprimidas \n\n') ) {
					submitform( pressbutton );
				} else {
					return;
				}
			} else {
				submitform( pressbutton );
			}
		}
		//-->
		</script>
		<form action="index2.php" method="post" name="adminForm">
		<div id="overDiv" style="position:absolute; visibility:hidden; z-index:10000;"></div>
		<table cellpadding="1" cellspacing="1" border="0" width="100%">
		<tr>
			<td width="250"><table class="adminheading"><tr><th nowrap class="config">Configuraci�n Global</th></tr></table></td>
			<td width="270">
				<span class="componentheading">configuration.php:
				<?php echo is_writable( '../configuration.php' ) ? '<b><font color="green"> Puede ser escrito</font></b>' : '<b><font color="red"> No puede ser escrito</font></b>' ?>
				</span>
			</td>
			<?php
			if (mosIsChmodable('../configuration.php')) {
				if (is_writable('../configuration.php')) {
					?>
					<td>
						<input type="checkbox" id="disable_write" name="disable_write" value="1"/>
						<label for="disable_write">Proteger el archivo contra escritura una vez guardado</label>
					</td>
					<?php
				} else {
					?>
					<td>
						<input type="checkbox" id="enable_write" name="enable_write" value="1"/>
						<label for="enable_write">Anular la protecci�n contra escritura al guardar</label>
					</td>
				<?php
				} // if
			} // if
			?>
		</tr>
		</table>
			<?php
		$tabs->startPane("configPane");
		$tabs->startTab("Sitio","site-page");
			?>
			<table class="adminform">
			<tr>
				<td width="185">Sitio fuera de l�nea:</td>
				<td><?php echo $lists['offline']; ?></td>
			</tr>
			<tr>
				<td valign="top">Mensaje a mostrar cuando <br /> el sitio est� fuera de l�nea:</td>
				<td><textarea class="text_area" cols="60" rows="2" style="width:500px; height:40px" name="config_offline_message"><?php echo $row->config_offline_message; ?></textarea><?php
					$tip = 'Mensaje que se mostrar� cuando la Web est� fuera de l�nea';
					echo mosToolTip( $tip );
				?></td>
			</tr>
			<tr>
				<td valign="top">Mensaje de error del sistema:</td>
				<td><textarea class="text_area" cols="60" rows="2" style="width:500px; height:40px" name="config_error_message"><?php echo $row->config_error_message; ?></textarea><?php
					$tip = 'Mensaje que se mostrar� en la Web cuando Joomla no pueda conectar con la base de datos';
					echo mosToolTip( $tip );
				?></td>
			</tr>
			<tr>
				<td>Nombre del sitio:</td>
				<td><input class="text_area" type="text" name="config_sitename" size="50" value="<?php echo $row->config_sitename; ?>"/></td>
			</tr>
			<tr>
				<td>Mostrar enlaces no autorizados:</td>
				<td><?php echo $lists['shownoauth']; ?><?php
					$tip = 'Si seleccionas <strong>S�</strong>, se mostrar�n los enlaces en los contenidos que requieran el registro de los usuarios siempre que estos no hayan accedido al sistema. El usuario deber� acceder al sistema para leer el art�culo completamente.';
					echo mosToolTip( $tip );
				?></td>
			</tr>
			<tr>
				<td>Permitir el registro:</td>
				<td><?php echo $lists['allowUserRegistration']; ?><?php
					$tip = 'S�, permites el registro de usuarios';
					echo mosToolTip( $tip );
				?></td>
			</tr>
			<tr>
				<td>Usar activaci�n de cuentas nuevas:</td>
				<td><?php echo $lists['useractivation']; ?>
				<?php
					$tip = 'Si seleccionas <strong>S�</strong>, el usuario recibir� un correo con un enlace para activar su cuenta antes de poder entrar al sistema.';
					echo mosToolTip( $tip );
				?></td>
			</tr>
			<tr>
				<td>Direcci�n E-Mail �nica:</td>
				<td><?php echo $lists['uniquemail']; ?><?php
					$tip = 'Si seleccionas <strong>S�</strong>, no podr�n haber dos direcciones E-Mail id�nticas entre las direcciones de los usuarios';
					echo mosToolTip( $tip );
				?></td>
			</tr>
			<tr>
				<td>Acceso en la P�gina Principal:</td>
				<td>
					<?php echo $lists['frontend_login']; ?>
					<?php
					$tip = 'Si seleccionas <strong>NO</strong>, deshabilitar�s el acceso a la P�gina Principal, a�n cuando no est� asociado a una opci�n del men�. Tambi�n deshabilitar�s la funci�n de Registro';
					echo mosToolTip( $tip );
					?>
				</td>
			</tr>
			<tr>
				<td>Par�metros de usuario en la P�gina Principal:</td>
				<td>
					<?php echo $lists['frontend_userparams']; ?>
					<?php
					$tip = 'Si seleccionas <strong>NO</strong>, deshabilitar�s los Par�metros de Usuario en la P�gina Principal';
					echo mosToolTip( $tip );
					?>
				</td>
			</tr>
			<tr>
				<td>Depuraci�n del Sitio:</td>
				<td>
					<?php echo $lists['debug']; ?>
					<?php
					$tip = 'Si seleccionas <strong>S�</strong>, se mostrar� la informaci�n de diagn�stico y errores SQL en caso de estar presentes';
					echo mosToolTip( $tip );
					?>
				</td>
			</tr>
			<tr>
				<td>Editor WYSIWYG por defecto:</td>
				<td><?php echo $lists['editor']; ?></td>
			</tr>
			<tr>
				<td>Longitud de los listados:</td>
				<td>
					<?php echo $lists['list_limit']; ?>
					<?php
					$tip = 'Configura la longitud de los listados en la administraci�n para todos los administradores';
					echo mosToolTip( $tip );
					?>
				</td>
			</tr>
			<tr>
				<td>�cono del Sitio:</td>
				<td>
				<input class="text_area" type="text" name="config_favicon" size="20" value="<?php echo $row->config_favicon; ?>"/>
				<?php
				$tip = 'Si lo dejas en blanco, o no se encuentra el archivo, se usar� por defecto favicon.ico.';
				echo mosToolTip( $tip, 'Favourite Icon' );
				?>			
				</td>
			</tr>
			</table>
			<?php
		$tabs->endTab();
		$tabs->startTab("Local","Locale-page");
			?>
			<table class="adminform">
			<tr>
				<td width="185">Lenguaje:</td>
				<td><?php echo $lists['lang']; ?></td>
			</tr>
			<tr>
				<td width="185">Zona Horaria:</td>
				<td>
				<?php echo $lists['offset']; ?>
				<?php
				$tip = "La fecha y la hora configurada actualmente se mostrar� de la siguiente manera: " . mosCurrentDate(_DATE_FORMAT_LC2);
				echo mosToolTip($tip);
				?>			
				</td>
			</tr>
			<tr>
				<td width="185">Hora del Servidor:</td>
				<td>
				<input class="text_area" type="text" name="config_offset" size="15" value="<?php echo $row->config_offset; ?>" disabled="true"/>
				</td>
			</tr>
			<tr>
				<td width="185">C�digo del idioma <br />(ca_ES catal�n :: es_ES espa�ol):</td>
				<td>
				<input class="text_area" type="text" name="config_locale" size="15" value="<?php echo $row->config_locale; ?>"/><?php $tip = 'En versiones de PHP5+ dejarlo en blanco da buen resultado'; echo mosToolTip($tip);?>
				</td>
			</tr>
			</table>
			<?php
		$tabs->endTab();
		$tabs->startTab("Contenidos","content-page");
			?>
			<table border="1" class="adminform">
			<tr>
				<td colspan="3">* Estos par�metros controlan los elementos de salida*<br/><br/></td>
			</tr>
			<tr>
				<td width="350">Enlaces en los t�tulos:</td>
				<td width="140"><?php echo $lists['link_titles']; ?></td>
				<td><?php
					$tip = 'Si seleccionas <strong>S�</strong>, el t�tulo del art�culo de contenidos ser� un enlace al art�culo';
					echo mosToolTip( $tip );
				?></td>
			</tr>
			<tr>
				<td width="200">Enlace Leerlo Todo:</td>
				<td width="140"><?php echo $lists['readmore']; ?></td>
				<td><?php
					$tip = 'Si activas la casilla <STRONG>MOSTRAR</STRONG>, se habilitar� el enlace <STRONG>Leerlo todo</STRONG> si el art�culo tiene texto opcional y esta completo';
					echo mosToolTip( $tip );
				?></td>
			</tr>
			<tr>
				<td>Permitir la votaci�n de los art�culos:</td>
				<td><?php echo $lists['vote']; ?></td>
				<td><?php
					$tip = 'Si activas la casilla <STRONG>MOSTRAR</STRONG>, se activar� un sistema para poder calificar los art�culos';
					echo mosToolTip( $tip );
				?></td>
			</tr>
			<tr>
				<td>Nombre de los autores:</td>
				<td><?php echo $lists['hideAuthor']; ?></td>
				<td><?php
					$tip = 'Si activas la casilla <STRONG>MOSTRAR</STRONG>, aparecer�n los nombres de los autores de los art�culos. Esta es la configuraci�n global, pero puede ser cambiada en los men�s y en los art�culos.';
					echo mosToolTip( $tip );
				?></td>
			</tr>
			<tr>
				<td>Fecha y hora de creaci�n:</td>
				<td><?php echo $lists['hideCreateDate']; ?></td>
				<td><?php
					$tip = 'Si activas la casilla <STRONG>MOSTRAR</STRONG>, aparecer� la fecha y la hora de creaci�n de los art�culos. Esta es la configuraci�n global, pero puede ser cambiada en los men�s y en los art�culos.';
					echo mosToolTip( $tip );
				?></td>
			</tr>
			<tr>
				<td>Fecha y hora de modificaci�n:</td>
				<td><?php echo $lists['hideModifyDate']; ?></td>
				<td><?php
					$tip = 'Si activas la casilla <STRONG>MOSTRAR</STRONG>, aparecer� la fecha y la hora de modificaci�n de los art�culos. Esta es la configuraci�n global, pero puede ser cambiada en los men�s y en los art�culos.';
					echo mosToolTip( $tip );
				?></td>
			</tr>
			<tr>
				<td>Accesos:</td>
				<td><?php echo $lists['hits']; ?></td>
				<td><?php
					$tip = 'Si activas la casilla <STRONG>MOSTRAR</STRONG>, el n�mero de accesos a los art�culos se har� visible. Esta es la configuraci�n global, pero puede ser cambiada en los men�s y en los art�culos.';
					echo mosToolTip( $tip );
				?></td>
			</tr>
			<tr>
				<td>Icono PDF:</td>
				<td><?php echo $lists['hidePdf']; ?></td>
				<?php
				if (!is_writable( "$mosConfig_absolute_path/media/" )) {
					echo "<td align=\"left\">";
					echo mosToolTip('Opci�n no disponible porque el directorio /media no puede ser escrito');
					echo "</td>";
				} else {
					?>				
					<td>&nbsp;</td>
					<?php
				}
				?>		
			</tr>
			<tr>
				<td>Icono Imprimir:</td>
				<td><?php echo $lists['hidePrint']; ?></td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>Icono Recomendar a un Amigo:</td>
				<td><?php echo $lists['hideEmail']; ?></td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>Iconos:</td>
				<td><?php echo $lists['icons']; ?></td>
				<td><?php echo mosToolTip('Si activas la casilla <STRONG>MOSTRAR</STRONG>, se habilitar�n �conos para las utilidades de Imprimir, PDF y Enviar a un amigo. De lo contrario se mostrar� como texto.'); ?></td>
			</tr>
			<tr>
				<td>Tabla de contenidos en los art�culos con m�ltiples p�ginas:</td>
				<td><?php echo $lists['multipage_toc']; ?></td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>Bot�n Volver:</td>
				<td><?php echo $lists['back_button']; ?></td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>Navegaci�n por los art�culos:</td>
				<td><?php echo $lists['item_navigation']; ?></td>
				<td>&nbsp;</td>
			</tr>
		  <tr>
				<td>Itemid Modo Compatibilidad:</td>
				<td><?php echo $lists['itemid_compat']; ?></td>
				<td>&nbsp;</td>
			</tr>
			</table>
			<input type="hidden" name="config_multilingual_support" value="<?php echo $row->config_multilingual_support?>">
			<?php
		$tabs->endTab();
		$tabs->startTab("Base de datos","db-page");
			?>
			<table class="adminform">
			<tr>
				<td width="185">Nombre del servidor:</td>
				<td><input class="text_area" type="text" name="config_host" size="25" value="<?php echo $row->config_host; ?>"/></td>
			</tr>
			<tr>
				<td>Nombre usuario MySQL:</td>
				<td><input class="text_area" type="text" name="config_user" size="25" value="<?php echo $row->config_user; ?>"/></td>
			</tr>
			<tr>
				<td>Base de datos MySQL:</td>
				<td><input class="text_area" type="text" name="config_db" size="25" value="<?php echo $row->config_db; ?>"/></td>
			</tr>
			<tr>
				<td>Prefijo MySQL de la base de datos:</td>
				<td>
				<input class="text_area" type="text" name="config_dbprefix" size="10" value="<?php echo $row->config_dbprefix; ?>"/>
				&nbsp;<?php echo mosWarning('�� NO CAMBIES EL PREFIJO A MENOS QUE SEA ESTRICTAMENTE NECESARIO !!'); ?>
				</td>
			</tr>
			</table>
			<?php
		$tabs->endTab();
		$tabs->startTab("Servidor","server-page");
			?>
			<table class="adminform">
			<tr>
				<td width="185">Ruta absoluta:</td>
				<td width="450"><strong><?php echo $row->config_absolute_path; ?></strong></td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>Sitio en vivo:</td>
				<td><strong><?php echo $row->config_live_site; ?></strong></td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>Palabra secreta:</td>
				<td><strong><?php echo $row->config_secret; ?></strong></td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>Compresi�n GZIP de p�ginas:</td>
				<td>
				<?php echo $lists['gzip']; ?>
				<?php echo mosToolTip('Si el servidor soporta compresi�n'); ?>
				</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>Tiempo de vida de la sesi�n:</td>
				<td>
				<input class="text_area" type="text" name="config_lifetime" size="10" value="<?php echo $row->config_lifetime; ?>"/>
				&nbsp;segundos&nbsp;
				<?php echo mosWarning('Salida autom�tica del sistema pasados estos segundos sin actividad para usuarios del <strong>frontend</strong> del sitio. <br />�Valores mayores implican mayor riesgo de seguridad!'); ?>
				</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>Tiempo de vida de la sesi�n de administrador:</td>
				<td>
				<input class="text_area" type="text" name="config_session_life_admin" size="10" value="<?php echo $row->config_session_life_admin; ?>"/>
				&nbsp;segundos&nbsp;
				<?php echo mosWarning('Salida autom�tica del sistema despu�s de un tiempo de inactividad para usuarios del <strong>backend</strong> del sitio (Panel de Administraci�n). <br />�Valores mayores implican mayor riesgo de seguridad!'); ?>
				</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>Recordar P�gina de Administraci�n expirada:</td>
				<td>
				<?php echo $lists['admin_expired']; ?>
				<?php echo mosToolTip('Si la sesi�n expira y vuelves a ingresar dentro de los 10 minutos de salida del sistema, ser�s redireccionado a la p�gina que estabas tratando de ingresar cuando fuiste sacado del sistema.'); ?>
				</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>M�todo de Autentificaci�n de Sesi�n:</td>
				<td>
				<?php echo $lists['session_type']; ?>
				&nbsp;&nbsp;
				<?php echo mosWarning('<strong>�No cambies esto a menos que sepas lo que est�s haciendo!</strong><br /><br /> Si tienes un n�mero de usuarios usando AOL o detr�s de puertos proxy, quiz�s consideres usar el ajuste del nivel 2.' ); ?>
				</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>Reporte de errores:</td>
				<td><?php echo $lists['error_reporting']; ?></td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>Servidor de ayuda:</td>
				<td><input class="text_area" type="text" name="config_helpurl" size="50" value="<?php echo $row->config_helpurl; ?>"/></td>
			</tr>
			<tr>
				<?php
				$mode = 0;
				$flags = 0644;
				if ($row->config_fileperms!='') {
					$mode = 1;
					$flags = octdec($row->config_fileperms);
				} // if
				?>
				<td valign="top">Creaci�n de archivos:</td>
				<td>
					<fieldset><legend>Permisos de archivos</legend>
						<table cellpadding="1" cellspacing="1" border="0">
							<tr>
								<td><input type="radio" id="filePermsMode0" name="filePermsMode" value="0" onclick="changeFilePermsMode(0)"<?php if (!$mode) echo ' checked="checked"'; ?>/></td>
								<td><label for="filePermsMode0">No aplicar CHMOD a los nuevos archivos (usar por defecto los que proporciona el servidor)</label></td>
							</tr>
							<tr>
								<td><input type="radio" id="filePermsMode1" name="filePermsMode" value="1" onclick="changeFilePermsMode(1)"<?php if ($mode) echo ' checked="checked"'; ?>/></td>
								<td>
									<label for="filePermsMode1">Aplicar CHMOD a los nuevos archivos</label>
									<span id="filePermsValue"<?php if (!$mode) echo ' style="display:none"'; ?>>
									to:	<input class="text_area" type="text" readonly="readonly" name="config_fileperms" size="4" value="<?php echo $row->config_fileperms; ?>"/>
									</span>
									<span id="filePermsTooltip"<?php if ($mode) echo ' style="display:none"'; ?>>
									&nbsp;<?php echo mosToolTip('Selecciona esta opci�n para definir los permisos que tendr�n los nuevos archivos'); ?>
									</span>
								</td>
							</tr>
							<tr id="filePermsFlags"<?php if (!$mode) echo ' style="display:none"'; ?>>
								<td>&nbsp;</td>
								<td>
									<table cellpadding="0" cellspacing="1" border="0">
										<tr>
											<td style="padding:0px">Usuario:</td>
											<td style="padding:0px"><input type="checkbox" id="filePermsUserRead" name="filePermsUserRead" value="1" onclick="saveFilePerms()"<?php if ($flags & 0400) echo ' checked="checked"'; ?>/></td>
											<td style="padding:0px"><label for="filePermsUserRead">lectura</label></td>
											<td style="padding:0px"><input type="checkbox" id="filePermsUserWrite" name="filePermsUserWrite" value="1" onclick="saveFilePerms()"<?php if ($flags & 0200) echo ' checked="checked"'; ?>/></td>
											<td style="padding:0px"><label for="filePermsUserWrite">escritura</label></td>
											<td style="padding:0px"><input type="checkbox" id="filePermsUserExecute" name="filePermsUserExecute" value="1" onclick="saveFilePerms()"<?php if ($flags & 0100) echo ' checked="checked"'; ?>/></td>
											<td style="padding:0px" colspan="3"><label for="filePermsUserExecute">ejecuci�n</label></td>
										</tr>
										<tr>
											<td style="padding:0px">Grupo:</td>
											<td style="padding:0px"><input type="checkbox" id="filePermsGroupRead" name="filePermsGroupRead" value="1" onclick="saveFilePerms()"<?php if ($flags & 040) echo ' checked="checked"'; ?>/></td>
											<td style="padding:0px"><label for="filePermsGroupRead">lectura</label></td>
											<td style="padding:0px"><input type="checkbox" id="filePermsGroupWrite" name="filePermsGroupWrite" value="1" onclick="saveFilePerms()"<?php if ($flags & 020) echo ' checked="checked"'; ?>/></td>
											<td style="padding:0px"><label for="filePermsGroupWrite">escritura</label></td>
											<td style="padding:0px"><input type="checkbox" id="filePermsGroupExecute" name="filePermsGroupExecute" value="1" onclick="saveFilePerms()"<?php if ($flags & 010) echo ' checked="checked"'; ?>/></td>
											<td style="padding:0px" width="70"><label for="filePermsGroupExecute">ejecuci�n</label></td>
											<td><input type="checkbox" id="applyFilePerms" name="applyFilePerms" value="1"/></td>
											<td nowrap="nowrap">
												<label for="applyFilePerms">
													Aplicar a los archivos existentes
													&nbsp;<?php
													echo mosWarning(
														'Si aplicas esto se cambiar�n <em>todos los permisos de los archivos</em> del sitio Web.<br/>'.
														'<b>�EL USO INCORRECTO DE ESTA OPCI�N PUEDE DEJAR EL SITIO INOPERATIVO!</b>'
													);?>
												</label>
											</td>
										</tr>
										<tr>
											<td style="padding:0px">Todos:</td>
											<td style="padding:0px"><input type="checkbox" id="filePermsWorldRead" name="filePermsWorldRead" value="1" onclick="saveFilePerms()"<?php if ($flags & 04) echo ' checked="checked"'; ?>/></td>
											<td style="padding:0px"><label for="filePermsWorldRead">lectura</label></td>
											<td style="padding:0px"><input type="checkbox" id="filePermsWorldWrite" name="filePermsWorldWrite" value="1" onclick="saveFilePerms()"<?php if ($flags & 02) echo ' checked="checked"'; ?>/></td>
											<td style="padding:0px"><label for="filePermsWorldWrite">escritura</label></td>
											<td style="padding:0px"><input type="checkbox" id="filePermsWorldExecute" name="filePermsWorldExecute" value="1" onclick="saveFilePerms()"<?php if ($flags & 01) echo ' checked="checked"'; ?>/></td>
											<td style="padding:0px" colspan="4"><label for="filePermsWorldExecute">ejecuci�n</label></td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</fieldset>
				</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<?php
				$mode = 0;
				$flags = 0755;
				if ($row->config_dirperms!='') {
					$mode = 1;
					$flags = octdec($row->config_dirperms);
				} // if
				?>
				<td valign="top">Creaci�n de directorios:</td>
				<td>
					<fieldset><legend>Permisos de los directorios</legend>
						<table cellpadding="1" cellspacing="1" border="0">
							<tr>
								<td><input type="radio" id="dirPermsMode0" name="dirPermsMode" value="0" onclick="changeDirPermsMode(0)"<?php if (!$mode) echo ' checked="checked"'; ?>/></td>
								<td><label for="dirPermsMode0">No aplicar CHMOD a los nuevos directorios (usar por defecto los que proporciona el servidor)</label></td>
							</tr>
							<tr>
								<td><input type="radio" id="dirPermsMode1" name="dirPermsMode" value="1" onclick="changeDirPermsMode(1)"<?php if ($mode) echo ' checked="checked"'; ?>/></td>
								<td>
									<label for="dirPermsMode1">Aplicar CHMOD a los nuevos directorios</label>
									<span id="dirPermsValue"<?php if (!$mode) echo ' style="display:none"'; ?>>
									to: <input class="text_area" type="text" readonly="readonly" name="config_dirperms" size="4" value="<?php echo $row->config_dirperms; ?>"/>
									</span>
									<span id="dirPermsTooltip"<?php if ($mode) echo ' style="display:none"'; ?>>
									&nbsp;<?php echo mosToolTip('Selecciona esta opci�n para definir los permisos que tendr�n los nuevos directorios'); ?>
									</span>
								</td>
							</tr>
							<tr id="dirPermsFlags"<?php if (!$mode) echo ' style="display:none"'; ?>>
								<td>&nbsp;</td>
								<td>
									<table cellpadding="1" cellspacing="0" border="0">
										<tr>
											<td style="padding:0px">Usuario:</td>
											<td style="padding:0px"><input type="checkbox" id="dirPermsUserRead" name="dirPermsUserRead" value="1" onclick="saveDirPerms()"<?php if ($flags & 0400) echo ' checked="checked"'; ?>/></td>
											<td style="padding:0px"><label for="dirPermsUserRead">lectura</label></td>
											<td style="padding:0px"><input type="checkbox" id="dirPermsUserWrite" name="dirPermsUserWrite" value="1" onclick="saveDirPerms()"<?php if ($flags & 0200) echo ' checked="checked"'; ?>/></td>
											<td style="padding:0px"><label for="dirPermsUserWrite">escritura</label></td>
											<td style="padding:0px"><input type="checkbox" id="dirPermsUserSearch" name="dirPermsUserSearch" value="1" onclick="saveDirPerms()"<?php if ($flags & 0100) echo ' checked="checked"'; ?>/></td>
											<td style="padding:0px" colspan="3"><label for="dirPermsUserSearch">b�squeda</label></td>
										</tr>
										<tr>
											<td style="padding:0px">Grupo:</td>
											<td style="padding:0px"><input type="checkbox" id="dirPermsGroupRead" name="dirPermsGroupRead" value="1" onclick="saveDirPerms()"<?php if ($flags & 040) echo ' checked="checked"'; ?>/></td>
											<td style="padding:0px"><label for="dirPermsGroupRead">lectura</label></td>
											<td style="padding:0px"><input type="checkbox" id="dirPermsGroupWrite" name="dirPermsGroupWrite" value="1" onclick="saveDirPerms()"<?php if ($flags & 020) echo ' checked="checked"'; ?>/></td>
											<td style="padding:0px"><label for="dirPermsGroupWrite">escritura</label></td>
											<td style="padding:0px"><input type="checkbox" id="dirPermsGroupSearch" name="dirPermsGroupSearch" value="1" onclick="saveDirPerms()"<?php if ($flags & 010) echo ' checked="checked"'; ?>/></td>
											<td style="padding:0px" width="70"><label for="dirPermsGroupSearch">b�squeda</label></td>
											<td><input type="checkbox" id="applyDirPerms" name="applyDirPerms" value="1"/></td>
											<td nowrap="nowrap">
												<label for="applyDirPerms">
													Aplicar a los directorios existentes
													&nbsp;<?php
													echo mosWarning(
														'Activando esta casilla se aplicar�n los permisos para <em>todos los directorios existentes</em> del sitio.<br/>'.
														'<b>�EL USO INCORRECTO DE ESTA OPCI�N PUEDE DEJAR EL SITIO INOPERATIVO!</b>'
													);?>
												</label>
											</td>
										</tr>
										<tr>
											<td style="padding:0px">Todos:</td>
											<td style="padding:0px"><input type="checkbox" id="dirPermsWorldRead" name="dirPermsWorldRead" value="1" onclick="saveDirPerms()"<?php if ($flags & 04) echo ' checked="checked"'; ?>/></td>
											<td style="padding:0px"><label for="dirPermsWorldRead">lectura</label></td>
											<td style="padding:0px"><input type="checkbox" id="dirPermsWorldWrite" name="dirPermsWorldWrite" value="1" onclick="saveDirPerms()"<?php if ($flags & 02) echo ' checked="checked"'; ?>/></td>
											<td style="padding:0px"><label for="dirPermsWorldWrite">escritura</label></td>
											<td style="padding:0px"><input type="checkbox" id="dirPermsWorldSearch" name="dirPermsWorldSearch" value="1" onclick="saveDirPerms()"<?php if ($flags & 01) echo ' checked="checked"'; ?>/></td>
											<td style="padding:0px" colspan="3"><label for="dirPermsWorldSearch">b�dqueda</label></td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</fieldset>
				</td>
				<td>&nbsp;</td>
			  </tr>
			<tr>
				<?php
				$rgmode = 0;
				if( defined( 'RG_EMULATION' ) ) {
					$rgmode = RG_EMULATION;
				}
				?>
				<td valign="top">Emulaci�n de los registros globales:</td>
				<td>
					<fieldset><legend>Registros Globales Emulaci�n</legend>
						<table cellpadding="1" cellspacing="1" border="0">
							<tr>
								<td><input type="radio" id="rgemulation" name="rgemulation" value="0"<?php if (!$rgmode) echo ' checked="checked"'; ?>/></td>
								<td><label for="rgemulation">OFF - m�s seguro y preferido</label></td>
							</tr>
							<tr>
								<td><input type="radio" id="rgemulation" name="rgemulation" value="1"<?php if ($rgmode) echo ' checked="checked"'; ?>/></td>
								<td><label for="rgemulation">ON - una compatibilidad mejor pero menos segura</label></td>
							</tr>
							</tr>
						</table>
					</fieldset>
				</td>
				<td>&nbsp;</td>
			</tr>

			</table>
			<?php
		$tabs->endTab();
		$tabs->startTab("Metadatos","metadata-page");
			?>
			<table class="adminform">
			<tr>
				<td width="185" valign="top">Descripci�n del Sitio:</td>
				<td><textarea class="text_area" cols="50" rows="3" style="width:500px; height:50px" name="config_MetaDesc"><?php echo $row->config_MetaDesc; ?></textarea></td>
			</tr>
			<tr>
				<td valign="top">Palabras Clave:</td>
				<td><textarea class="text_area" cols="50" rows="3" style="width:500px; height:50px" name="config_MetaKeys"><?php echo $row->config_MetaKeys; ?></textarea></td>
			</tr>
			<tr>
				<td valign="top">T�tulo del Sitio:</td>
				<td>
				<?php echo $lists['MetaTitle']; ?>
				&nbsp;&nbsp;&nbsp;
				<?php echo mosToolTip('Mostrar el t�tulo del art�culo en la Barra de T�tulos del navegador'); ?>
				</td>
		  	  </tr>
			<tr>
				<td valign="top">Mostrar Metadatos de Autor:</td>
				<td>
				<?php echo $lists['MetaAuthor']; ?>
				&nbsp;&nbsp;&nbsp;
				<?php echo mosToolTip('Muestra los Metadatos del autor mientras se visualiza el contenido del art�culo'); ?>
				</td>
			</tr>
			</table>
			<?php
		$tabs->endTab();
		$tabs->startTab("Correo","mail-page");
			?>
			<table class="adminform">
			<tr>
				<td width="185">Gesti�n de correo electr�nico:</td>
				<td><?php echo $lists['mailer']; ?></td>
			</tr>
			<tr>
				<td>Correo del remitente:</td>
				<td><input class="text_area" type="text" name="config_mailfrom" size="50" value="<?php echo $row->config_mailfrom; ?>"/></td>
			</tr>
			<tr>
				<td>Nombre del remitente:</td>
				<td><input class="text_area" type="text" name="config_fromname" size="50" value="<?php echo $row->config_fromname; ?>"/></td>
			</tr>
			<tr>
				<td>Ruta del Sendmail:</td>
				<td><input class="text_area" type="text" name="config_sendmail" size="50" value="<?php echo $row->config_sendmail; ?>"/></td>
			</tr>
			<tr>
				<td>Autentificaci�n SMTP:</td>
				<td><?php echo $lists['smtpauth']; ?></td>
			</tr>
			<tr>
				<td>Usuario SMTP:</td>
				<td><input class="text_area" type="text" name="config_smtpuser" size="50" value="<?php echo $row->config_smtpuser; ?>"/></td>
			</tr>
			<tr>
				<td>Contrase�a SMTP:</td>
				<td><input class="text_area" type="text" name="config_smtppass" size="50" value="<?php echo $row->config_smtppass; ?>"/></td>
			</tr>
			<tr>
				<td>Servidor SMTP:</td>
				<td><input class="text_area" type="text" name="config_smtphost" size="50" value="<?php echo $row->config_smtphost; ?>"/></td>
			</tr>
			</table>
			<?php
		$tabs->endTab();
		$tabs->startTab("Cach�","cache-page");
			?>
			<table class="adminform" border="0">
			<?php
			if (is_writeable($row->config_cachepath)) {
				?>
				<tr>
					<td width="185">Activar Cach�:</td>
					<td width="500"><?php echo $lists['caching']; ?></td>
					<td>&nbsp;</td>
				</tr>
				<?php
			}
			?>
			<tr>
				<td>Directorio para la Cach�:</td>
				<td>
				<input class="text_area" type="text" name="config_cachepath" size="50" value="<?php echo $row->config_cachepath; ?>"/>
				<?php
				if (is_writeable($row->config_cachepath)) {
					echo mosToolTip('Actualmente el directorio para la cach� <b>puede ser escrito</b>');
				} else {
					echo mosWarning('El directorio para la cach� no puede ser escrito - debes dar permisos CHMOD 755 al directorio antes de activar la cach�');
				}
				?>			
				</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>Refrescamiento de la Cach�:</td>
				<td><input class="text_area" type="text" name="config_cachetime" size="5" value="<?php echo $row->config_cachetime; ?>"/> segundos</td>
				<td>&nbsp;</td>
			</tr>
			</table>
			<?php
		$tabs->endTab();
		$tabs->startTab("Estad�sticas","stats-page");
			?>
			<table class="adminform">
			<tr>
				<td width="185">Estad�sticas:</td>
				<td width="100"><?php echo $lists['enable_stats']; ?></td>
				<td><?php echo mostooltip('Activar/Desactivar colecci�n de estad�sticas del sitio'); ?></td>
			</tr>
			<tr>
				<td>Registro de accesos por fechas:</td>
				<td><?php echo $lists['log_items']; ?></td>
				<td><span class="error"><?php echo mosWarning('ADVERTENCIA: Esto genera una gran cantidad de datos'); ?></span></td>
			</tr>
			<tr>
				<td>Registro de b�squedas:</td>
				<td><?php echo $lists['log_searches']; ?></td>
				<td>&nbsp;</td>
			</tr>
			</table>
			<?php
		$tabs->endTab();
		$tabs->startTab("SEO","seo-page");
			?>
			<table class="adminform">
			<tr>
				<td width="200"><strong>Optimizaci�n SEO para buscadores</strong></td>
				<td width="100">&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>URLs amigables para buscadores:</td>
				<td><?php echo $lists['sef']; ?>&nbsp;</td>
				<td><span class="error"><?php echo mosWarning('S�lo Apache! Debes renombrar tu archivo htaccess.txt a .htaccess antes de activar esta opci�n'); ?></span></td>
			</tr>
			<tr>
				<td>T�tulos din�micos en las p�ginas:</td>
				<td><?php echo $lists['pagetitles']; ?></td>
				<td><?php echo mosToolTip('Cambiar din�micamente el t�tulo de las p�ginas para reflejar el contenido'); ?></td>
			</tr>
			</table>
			<?php
		$tabs->endTab();
		$tabs->endPane();
		
		// show security setting check
		josSecurityCheck();
        ?>
		
		<input type="hidden" name="option" value="<?php echo $option; ?>"/>
		<input type="hidden" name="config_absolute_path" value="<?php echo $row->config_absolute_path; ?>"/>
		<input type="hidden" name="config_live_site" value="<?php echo $row->config_live_site; ?>"/>
		<input type="hidden" name="config_secret" value="<?php echo $row->config_secret; ?>"/>
	  	<input type="hidden" name="task" value=""/>
		</form>
		<script  type="text/javascript" src="<?php echo $mosConfig_live_site;?>/includes/js/overlib_mini.js"></script>
		<?php
	}

}
?>