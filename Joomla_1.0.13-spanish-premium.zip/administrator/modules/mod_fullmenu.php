<?php
/**
* @version $Id: mod_fullmenu.php 6070 2006-12-20 02:09:09Z robs $
* @translator http://www.joomlaspanish.org 2006-06-25 
* shacker review:28-12-2006
* @package Joomla
* @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// no direct access
defined( '_VALID_MOS' ) or die( 'Acceso restringido' );

      if (!defined( '_JOS_FULLMENU_MODULE' )) {
/** ensure that functions are declared only once */
  	  define( '_JOS_FULLMENU_MODULE', 1 );

/**
* Full DHTML Admnistrator Menus
* @package Joomla
*/
class mosFullAdminMenu {
	/**
	* Show the menu
	* @param string The current user type
	*/
	function show( $usertype='' ) {
		global $acl, $database;
		global $mosConfig_live_site, $mosConfig_enable_stats, $mosConfig_caching;

		// cache some acl checks
		$canConfig 			= $acl->acl_check( 'administration', 'config', 'users', $usertype );

		$manageTemplates 	= $acl->acl_check( 'administration', 'manage', 'users', $usertype, 'components', 'com_templates' );
		$manageTrash 		= $acl->acl_check( 'administration', 'manage', 'users', $usertype, 'components', 'com_trash' );
		$manageMenuMan 		= $acl->acl_check( 'administration', 'manage', 'users', $usertype, 'components', 'com_menumanager' );
		$manageLanguages 	= $acl->acl_check( 'administration', 'manage', 'users', $usertype, 'components', 'com_languages' );
		$installModules 	= $acl->acl_check( 'administration', 'install', 'users', $usertype, 'modules', 'all' );
		$editAllModules 	= $acl->acl_check( 'administration', 'edit', 'users', $usertype, 'modules', 'all' );
		$installMambots 	= $acl->acl_check( 'administration', 'install', 'users', $usertype, 'mambots', 'all' );
		$editAllMambots 	= $acl->acl_check( 'administration', 'edit', 'users', $usertype, 'mambots', 'all' );
		$installComponents 	= $acl->acl_check( 'administration', 'install', 'users', $usertype, 'components', 'all' );
		$editAllComponents 	= $acl->acl_check( 'administration', 'edit', 'users', $usertype, 'components', 'all' );
		$canMassMail 		= $acl->acl_check( 'administration', 'manage', 'users', $usertype, 'components', 'com_massmail' );
		$canManageUsers 	= $acl->acl_check( 'administration', 'manage', 'users', $usertype, 'components', 'com_users' );

		$query = "SELECT a.id, a.title, a.name"
		. "\n FROM #__sections AS a"
		. "\n WHERE a.scope = 'content'"
		. "\n GROUP BY a.id"
		. "\n ORDER BY a.ordering"
		;
		$database->setQuery( $query );
		$sections = $database->loadObjectList();
		
		$menuTypes = mosAdminMenus::menutypes();
		?>
		<div id="myMenuID"></div>
		<script language="JavaScript" type="text/javascript">
		var myMenu =
		[
		<?php
	// Home Sub-Menu
?>			[null,'Inicio','index2.php',null,'Panel de Control'],
			_cmSplit,
			<?php
	// Site Sub-Menu
?>			[null,'Sitio',null,null,'Administrar sitio',
<?php
			if ($canConfig) {
?>				['<img src="../includes/js/ThemeOffice/config.png" />','Configuraci�n Global','index2.php?option=com_config&hidemainmenu=1',null,'Configuraci�n'],
<?php
			}
			if ($manageLanguages) {
?>				['<img src="../includes/js/ThemeOffice/language.png" />','Administrador de Idiomas',null,null,'Administrar idiomas',
  					['<img src="../includes/js/ThemeOffice/language.png" />','Idiomas del Sitio','index2.php?option=com_languages',null,'Administrar idiomas'],
   				],
<?php
			}
?>				['<img src="../includes/js/ThemeOffice/media.png" />','Administrador de Im�genes','index2.php?option=com_media',null,'Administrar im�genes'],
					['<img src="../includes/js/ThemeOffice/preview.png" />', 'Vista Previa', null, null, 'Previo',
					['<img src="../includes/js/ThemeOffice/preview.png" />','En una Nueva Ventana','<?php echo $mosConfig_live_site; ?>/index.php','_blank','<?php echo $mosConfig_live_site; ?>'],
					['<img src="../includes/js/ThemeOffice/preview.png" />','En L�nea','index2.php?option=com_admin&task=preview',null,'<?php echo $mosConfig_live_site; ?>'],
					['<img src="../includes/js/ThemeOffice/preview.png" />','En L�nea con las Posiciones','index2.php?option=com_admin&task=preview2',null,'<?php echo $mosConfig_live_site; ?>'],
				],
				['<img src="../includes/js/ThemeOffice/globe1.png" />', 'Estad�sticas', null, null, 'Estad�sticas del Sitio',
<?php
			if ($mosConfig_enable_stats == 1) {
?>					['<img src="../includes/js/ThemeOffice/globe4.png" />', 'Navegadores, SO, Dominios', 'index2.php?option=com_statistics', null, 'Navegadores, OS, Dominios'],
<?php
			}
?>					['<img src="../includes/js/ThemeOffice/search_text.png" />', 'Texto Buscado', 'index2.php?option=com_statistics&task=searches', null, 'Texto buscado']
				],
<?php
			if ($manageTemplates) {
?>				['<img src="../includes/js/ThemeOffice/template.png" />','Administrador de Plantillas',null,null,'Cambiar la plantilla del sitio',
  					['<img src="../includes/js/ThemeOffice/template.png" />','Plantillas del Sitio','index2.php?option=com_templates',null,'Cambiar la plantilla del sitio'],
  					_cmSplit,
  					['<img src="../includes/js/ThemeOffice/template.png" />','Plantillas del Administrador','index2.php?option=com_templates&client=admin',null,'Cambiar plantillas de la administraci�n'],
  					_cmSplit,
  					['<img src="../includes/js/ThemeOffice/template.png" />','Posiciones de los M�dulos','index2.php?option=com_templates&task=positions',null,'Plantilla de posiciones']
  				],
<?php
			}
			if ($manageTrash) {
?>				['<img src="../includes/js/ThemeOffice/trash.png" />','Administrador de la Papelera','index2.php?option=com_trash',null,'Administrar la papelera'],
<?php
			}
			if ($canManageUsers || $canMassMail) {
?>				['<img src="../includes/js/ThemeOffice/users.png" />','Administrador de Usuarios','index2.php?option=com_users&task=view',null,'Administrar usuarios'],
<?php
				}
?>			],
<?php
	// Menu Sub-Menu
?>			_cmSplit,
			[null,'Men�s',null,null,'Administrar men�',
<?php
			if ($manageMenuMan) {
?>				['<img src="../includes/js/ThemeOffice/menus.png" />','Administrador de Men�s','index2.php?option=com_menumanager',null,'Administrar men�s'],
				_cmSplit,
<?php
			}
			foreach ( $menuTypes as $menuType ) {
?>				['<img src="../includes/js/ThemeOffice/menus.png" />','<?php echo $menuType;?>','index2.php?option=com_menus&menutype=<?php echo $menuType;?>',null,''],
<?php
			}
?>			],
			_cmSplit,
<?php
	// Content Sub-Menu
?>			[null,'Contenido',null,null,'Administrar contenido',
<?php
			if (count($sections) > 0) {
?>				['<img src="../includes/js/ThemeOffice/edit.png" />','Contenido por Secci�n',null,null,'Contenido por secci�n',
<?php
				foreach ($sections as $section) {
					$txt = addslashes( $section->title ? $section->title : $section->name );
?>					['<img src="../includes/js/ThemeOffice/document.png" />','<?php echo $txt;?>', null, null,'<?php echo $txt;?>',
						['<img src="../includes/js/ThemeOffice/edit.png" />', '<?php echo $txt;?> Art�culos', 'index2.php?option=com_content&sectionid=<?php echo $section->id;?>',null,null],
						['<img src="../includes/js/ThemeOffice/backup.png" />', '<?php echo $txt;?> Archivo','index2.php?option=com_content&task=showarchive&sectionid=<?php echo $section->id;?>',null,null],
						['<img src="../includes/js/ThemeOffice/add_section.png" />', '<?php echo $txt;?> Categor�as', 'index2.php?option=com_categories&section=<?php echo $section->id;?>',null, null],
					],

<?php
				} // foreach
?>				],
				_cmSplit,
<?php
			}
?>
				['<img src="../includes/js/ThemeOffice/edit.png" />','Todos los Art�culos de Contenido','index2.php?option=com_content&sectionid=0',null,'Administar todos los art�culos con contenido'],
  				['<img src="../includes/js/ThemeOffice/edit.png" />','Administrador de Contenido Est�tico','index2.php?option=com_typedcontent',null,'Administar art�culos con contenido'],
  				_cmSplit,
  				['<img src="../includes/js/ThemeOffice/add_section.png" />','Administrador de Secciones','index2.php?option=com_sections&scope=content',null,'Administrar el contenido de las secciones'],
				['<img src="../includes/js/ThemeOffice/add_section.png" />','Administrador de Categor�as','index2.php?option=com_categories&section=content',null,'Administrar el contenido de las categor�as'],
				_cmSplit,
  				['<img src="../includes/js/ThemeOffice/home.png" />','Administrador de la P�gina de Inicio','index2.php?option=com_frontpage',null,'Administrar los art�culos de la p�gina de inicio'],
  				['<img src="../includes/js/ThemeOffice/edit.png" />','Administrador del Archivo','index2.php?option=com_content&task=showarchive&sectionid=0',null,'Administrar contenidos archivados'],
  				['<img src="../includes/js/ThemeOffice/globe3.png" />', 'Impresiones por P�gina', 'index2.php?option=com_statistics&task=pageimp', null, 'Impresiones por p�gina'],
			],
<?php
	// Components Sub-Menu
	if ($installComponents) {
?>			_cmSplit,
			[null,'Componentes',null,null,'Administrar componentes',
<?php
		$query = "SELECT *"
		. "\n FROM #__components"
		. "\n WHERE name != 'frontpage'"
		. "\n AND name != 'media manager'"
		. "\n ORDER BY ordering, name"
		;
		$database->setQuery( $query );
		$comps = $database->loadObjectList();	// component list
		$subs = array();	// sub menus
		// first pass to collect sub-menu items
		foreach ($comps as $row) {
			if ($row->parent) {
				if (!array_key_exists( $row->parent, $subs )) {
					$subs[$row->parent] = array();
				}
				$subs[$row->parent][] = $row;
			}
		}
		$topLevelLimit = 19; //You can get 19 top levels on a 800x600 Resolution
		$topLevelCount = 0;
		foreach ($comps as $row) {
			if ($editAllComponents | $acl->acl_check( 'administration', 'edit', 'users', $usertype, 'components', $row->option )) {
				if ($row->parent == 0 && (trim( $row->admin_menu_link ) || array_key_exists( $row->id, $subs ))) {
					$topLevelCount++;
					if ($topLevelCount > $topLevelLimit) {
						continue;
					}
					$name = addslashes( $row->name );
					$alt = addslashes( $row->admin_menu_alt );
					$link = $row->admin_menu_link ? "'index2.php?$row->admin_menu_link'" : "null";
					echo "\t\t\t\t['<img src=\"../includes/$row->admin_menu_img\" />','$name',$link,null,'$alt'";
					if (array_key_exists( $row->id, $subs )) {
						foreach ($subs[$row->id] as $sub) {
							echo ",\n";
							$name = addslashes( $sub->name );
							$alt = addslashes( $sub->admin_menu_alt );
							$link = $sub->admin_menu_link ? "'index2.php?$sub->admin_menu_link'" : "null";
							echo "\t\t\t\t\t['<img src=\"../includes/$sub->admin_menu_img\" />','$name',$link,null,'$alt']";
						}
					}
					echo "\n\t\t\t\t],\n";
				}
			}
		}
		if ($topLevelLimit < $topLevelCount) {
			echo "\t\t\t\t['<img src=\"../includes/js/ThemeOffice/sections.png\" />','M�s componentes...','index2.php?option=com_admin&task=listcomponents',null,'M�s componentes'],\n";
		}
?>
			],
<?php
	// Modules Sub-Menu
		if ($installModules | $editAllModules) {
?>			_cmSplit,
			[null,'M�dulos',null,null,'Administrar m�dulos',
<?php
			if ($editAllModules) {
?>				['<img src="../includes/js/ThemeOffice/module.png" />', 'M�dulos del Sitio', "index2.php?option=com_modules", null, 'Administrar m�dulos del sitio'],
				['<img src="../includes/js/ThemeOffice/module.png" />', 'M�dulos del Administrador', "index2.php?option=com_modules&client=admin", null, 'Administar m�dulos del administrador'],
<?php
			}
?>			],
<?php
		} // if ($installModules | $editAllModules)
	} // if $installComponents
	// Mambots Sub-Menu
	if ($installMambots | $editAllMambots) {
?>			_cmSplit,
			[null,'Mambots',null,null,'Administrar mambot',
<?php
		if ($editAllMambots) {
?>				['<img src="../includes/js/ThemeOffice/module.png" />', 'Administrador de Mambots', "index2.php?option=com_mambots", null, 'Mambots del Sitio'],
<?php
		}
?>			],
<?php
	}
?>
<?php
	// Installer Sub-Menu
	if ($installModules) {
?>			_cmSplit,
			[null,'Instaladores',null,null,'Lista de instaladores',
<?php
		if ($manageTemplates) {
?>				['<img src="../includes/js/ThemeOffice/install.png" />','Plantillas - Sitio','index2.php?option=com_installer&element=template&client=',null,'Instalar plantillas - sitio'],
				['<img src="../includes/js/ThemeOffice/install.png" />','Plantillas - Admin','index2.php?option=com_installer&element=template&client=admin',null,'Instalar plantillas - admin'],
<?php
		}
		if ($manageLanguages) {
?>				['<img src="../includes/js/ThemeOffice/install.png" />','Idiomas','index2.php?option=com_installer&element=language',null,'Instalar idiomas'],
				_cmSplit,
<?php
		}
?>				['<img src="../includes/js/ThemeOffice/install.png" />', 'Componentes','index2.php?option=com_installer&element=component',null,'Instalar/desinstalar componentes'],
				['<img src="../includes/js/ThemeOffice/install.png" />', 'M�dulos', 'index2.php?option=com_installer&element=module', null, 'Install/Uninstall Modules'],
				['<img src="../includes/js/ThemeOffice/install.png" />', 'Mambots', 'index2.php?option=com_installer&element=mambot', null, 'Install/Uninstall Mambots'],
			],
<?php
	} // if ($installModules)
	// Messages Sub-Menu
	if ($canConfig) {
?>			_cmSplit,
  			[null,'Mensajes',null,null,'Gerencia de la mensajer�a',
  				['<img src="../includes/js/ThemeOffice/messaging_inbox.png" />','Buz�n de Entrada','index2.php?option=com_messages',null,'Mensajes privados'],
  				['<img src="../includes/js/ThemeOffice/messaging_config.png" />','Configuraci�n','index2.php?option=com_messages&task=config&hidemainmenu=1',null,'Configuraci�n']
  			],
<?php
	// System Sub-Menu
		/*
	?>			_cmSplit,
	  			[null,'System',null,null,'System Management',
	  				['<img src="../includes/js/ThemeOffice/joomla_16x16.png" />', 'Version Check', 'index2.php?option=com_admin&task=versioncheck', null,'Version Check'],
	  				['<img src="../includes/js/ThemeOffice/sysinfo.png" />', 'System Info', 'index2.php?option=com_admin&task=sysinfo', null,'System Information'],
	<?php
		*/
	?>			_cmSplit,
	  			[null,'Sistema',null,null,'Administrador del sistema',
	  				['<img src="../includes/js/ThemeOffice/joomla_16x16.png" />', 'Revisar Versi�n', 'http://www.joomla.org/latest10', '_blank','Revisar Versi�n'],
	  				['<img src="../includes/js/ThemeOffice/sysinfo.png" />', 'Informaci�n del sistema', 'index2.php?option=com_admin&task=sysinfo', null,'Informaci�n del sistema'],
	<?php
	  		if ($canConfig) {
	?>
					['<img src="../includes/js/ThemeOffice/checkin.png" />', 'Validaci�n Global', 'index2.php?option=com_checkin', null,'Validaci�n Global de todos los �tems'],
	<?php
				if ($mosConfig_caching) {
	?>				['<img src="../includes/js/ThemeOffice/config.png" />','Limpiar Contenido de la Cach�','index2.php?option=com_admin&task=clean_cache',null,'Limpiar Contenido de la Cach�'],
					['<img src="../includes/js/ThemeOffice/config.png" />','Limpiar Todas las Caches','index2.php?option=com_admin&task=clean_all_cache',null,'Limpiar Todas las Caches'],
	<?php
				}
			}
	?>			],
	<?php
				}
	?>			_cmSplit,
	<?php
		// Help Sub-Menu
?>			[null,'Ayuda','index2.php?option=com_admin&task=help',null,null]
		];
		cmDraw ('myMenuID', myMenu, 'hbr', cmThemeOffice, 'ThemeOffice');
		</script>
<?php
	}

    /**
	* Show an disbaled version of the menu, used in edit pages
	* @param string The current user type
	*/
    function showDisabled( $usertype='' ) {
		global $acl;

		$canConfig 			= $acl->acl_check( 'administration', 'config', 'users', $usertype );
		$installModules 	= $acl->acl_check( 'administration', 'install', 'users', $usertype, 'modules', 'all' );
		$editAllModules 	= $acl->acl_check( 'administration', 'edit', 'users', $usertype, 'modules', 'all' );
		$installMambots 	= $acl->acl_check( 'administration', 'install', 'users', $usertype, 'mambots', 'all' );
		$editAllMambots 	= $acl->acl_check( 'administration', 'edit', 'users', $usertype, 'mambots', 'all' );
		$installComponents 	= $acl->acl_check( 'administration', 'install', 'users', $usertype, 'components', 'all' );
		$editAllComponents 	= $acl->acl_check( 'administration', 'edit', 'users', $usertype, 'components', 'all' );
		$canMassMail 		= $acl->acl_check( 'administration', 'manage', 'users', $usertype, 'components', 'com_massmail' );
		$canManageUsers 	= $acl->acl_check( 'administration', 'manage', 'users', $usertype, 'components', 'com_users' );

		$text = 'Men� inactivo para esta p�gina';
		?>
		<div id="myMenuID" class="inactive"></div>
		<script language="JavaScript" type="text/javascript">
		var myMenu =
		[
		<?php
	/* Home Sub-Menu */
		?>
			[null,'<?php echo 'Inicio'; ?>',null,null,'<?php echo $text; ?>'],
			_cmSplit,
		<?php
	/* Site Sub-Menu */
		?>
			[null,'<?php echo 'Sitio'; ?>',null,null,'<?php echo $text; ?>'
			],
		<?php
	/* Menu Sub-Menu */
		?>
			_cmSplit,
			[null,'<?php echo 'Men�'; ?>',null,null,'<?php echo $text; ?>'
			],
			_cmSplit,
		<?php
	/* Content Sub-Menu */
		?>
 			[null,'<?php echo 'Contenido'; ?>',null,null,'<?php echo $text; ?>'
			],
		<?php
	/* Components Sub-Menu */
			if ( $installComponents) {
				?>
				_cmSplit,
				[null,'<?php echo 'Componentes'; ?>',null,null,'<?php echo $text; ?>'
				],
				<?php
			} // if $installComponents
			?>
		<?php
	/* Modules Sub-Menu */
			if ( $installModules | $editAllModules) {
				?>
				_cmSplit,
				[null,'<?php echo 'M�dulos'; ?>',null,null,'<?php echo $text; ?>'
				],
				<?php
			} // if ( $installModules | $editAllModules)
			?>
		<?php
	/* Mambots Sub-Menu */
			if ( $installMambots | $editAllMambots) {
				?>
				_cmSplit,
				[null,'<?php echo 'Mambots-Plugins'; ?>',null,null,'<?php echo $text; ?>'
				],
				<?php
			} // if ( $installMambots | $editAllMambots)
			?>


			<?php
	/* Installer Sub-Menu */
			if ( $installModules) {
				?>
				_cmSplit,
				[null,'<?php echo 'Instaladores'; ?>',null,null,'<?php echo $text; ?>'
					<?php
					?>
				],
				<?php
			} // if ( $installModules)
			?>
			<?php
	/* Messages Sub-Menu */
			if ( $canConfig) {
				?>
				_cmSplit,
	  			[null,'<?php echo 'Mensajes'; ?>',null,null,'<?php echo $text; ?>'
	  			],
				<?php
			}
			?>

			<?php
	/* System Sub-Menu */
			if ( $canConfig) {
				?>
				_cmSplit,
	  			[null,'<?php echo 'Sistema'; ?>',null,null,'<?php echo $text; ?>'
				],
				<?php
			}
			?>
			_cmSplit,
			<?php
	/* Help Sub-Menu */
			?>
			[null,'<?php echo 'Ayuda'; ?>',null,null,'<?php echo $text; ?>']
		];
		cmDraw ('myMenuID', myMenu, 'hbr', cmThemeOffice, 'ThemeOffice');
		</script>
		<?php
	}
}
	}
$cache =& mosCache::getCache( 'mos_fullmenu' );

$hide = mosGetParam( $_REQUEST, 'hidemainmenu', 0 );

if ( $hide ) {
	mosFullAdminMenu::showDisabled( $my->usertype );
} else {
	mosFullAdminMenu::show( $my->usertype );
}
?>